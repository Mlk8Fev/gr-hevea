<aside class="sidebar">
    <button type="button" class="sidebar-close-btn">
        <iconify-icon icon="radix-icons:cross-2"></iconify-icon>
    </button>
    <div>
        <a href="<?php echo e(route('dashboard')); ?>" class="sidebar-logo">
            <img src="<?php echo e(asset('wowdash/images/fph-ci.png')); ?>" alt="FPH-CI Logo" class="light-logo" style="max-width: 150px; height: auto;">
            <img src="<?php echo e(asset('wowdash/images/fph-ci.png')); ?>" alt="FPH-CI Logo" class="dark-logo" style="max-width: 150px; height: auto;">
            <img src="<?php echo e(asset('wowdash/images/fph-ci.png')); ?>" alt="FPH-CI Logo" class="logo-icon" style="max-width: 40px; height: auto;">
        </a>
    </div>
    <div class="sidebar-menu-area">
        <ul class="sidebar-menu" id="sidebar-menu">
            <?php $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item['type'] == 'title'): ?>
                    <li class="sidebar-menu-group-title"><?php echo e($item['title']); ?></li>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e($item['url']); ?>" class="<?php echo e($item['active'] ? 'active' : ''); ?>">
                            <iconify-icon icon="<?php echo e(str_replace('ri-', 'ri:', $item['icon'])); ?>" class="menu-icon"></iconify-icon>
                            <span><?php echo e($item['title']); ?></span>
                            <?php if(isset($item['badge'])): ?>
                                <span class="badge bg-danger ms-auto"><?php echo e($item['badge']); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</aside> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gr-hevea/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>