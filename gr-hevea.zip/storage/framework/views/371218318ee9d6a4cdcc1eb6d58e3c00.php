<!DOCTYPE html>
<html lang="fr" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facture <?php echo e($facture->numero_facture); ?> - WowDash</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('wowdash/images/favicon.png')); ?>" sizes="16x16">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/lib/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/lib/dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/style.css')); ?>">
</head>
<body>
<?php echo $__env->make('partials.sidebar', ['navigation' => $navigation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="dashboard-main">
    <?php echo $__env->make('partials.navbar-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <div class="dashboard-main-body">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
            <h6 class="fw-semibold mb-0">
                Facture <?php echo e($facture->numero_facture); ?>

            </h6>
            <ul class="d-flex align-items-center gap-2">
                <li class="fw-medium">
                    <a href="<?php echo e(route('dashboard')); ?>" class="d-flex align-items-center gap-1 hover-text-primary">
                        <iconify-icon icon="solar:home-smile-angle-outline" class="icon text-lg"></iconify-icon>
                        Dashboard
                    </a>
                </li>
                <li>-</li>
                <li class="fw-medium">
                    <a href="<?php echo e(route('admin.factures.index')); ?>" class="hover-text-primary">Factures</a>
                </li>
                <li>-</li>
                <li class="fw-medium"><?php echo e($facture->numero_facture); ?></li>
            </ul>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="ri-check-line me-2"></i><?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="ri-error-warning-line me-2"></i><?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- En-tête de la Facture -->
        <div class="card h-100 p-0 radius-12 mb-24">
            <div class="card-header border-bottom bg-base py-16 px-24">
                <div class="d-flex align-items-center justify-content-between">
                    <h6 class="mb-0">Informations de la Facture</h6>
                    <div class="d-flex align-items-center gap-2">
                        <?php if($facture->canBeValidated()): ?>
                            <form action="<?php echo e(route('admin.factures.validate', $facture)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary btn-sm" onclick="return confirm('Valider cette facture ?')">
                                    <iconify-icon icon="lucide:check" class="icon me-1"></iconify-icon>
                                    Valider
                                </button>
                            </form>
                        <?php endif; ?>
                        
                        <?php if($facture->canBePaid()): ?>
                            <button type="button" class="btn btn-success btn-sm" onclick="markAsPaid(<?php echo e($facture->id); ?>, <?php echo e($facture->montant_ttc); ?>)">
                                <iconify-icon icon="lucide:credit-card" class="icon me-1"></iconify-icon>
                                Marquer comme payée
                            </button>
                        <?php endif; ?>
                        
                        <?php if($facture->statut === 'validee'): ?>
                            <a href="<?php echo e(route('admin.factures.preview', $facture)); ?>" class="btn btn-primary">
                                <iconify-icon icon="lucide:file-text" class="icon me-1"></iconify-icon>
                                Preview PDF
                            </a>
                        <?php endif; ?>
                        
                        <?php if($facture->statut === 'brouillon'): ?>
                            <form action="<?php echo e(route('admin.factures.destroy', $facture)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Supprimer cette facture ?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">
                                    <iconify-icon icon="lucide:trash-2" class="icon me-1"></iconify-icon>
                                    Supprimer
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-body p-24">
                <div class="row">
                    <div class="col-md-6">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Numéro de facture</span>
                            <span class="fw-bold text-primary text-lg"><?php echo e($facture->numero_facture); ?></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Type</span>
                            <?php if($facture->type === 'individuelle'): ?>
                                <span class="badge bg-info fs-6">Individuelle</span>
                            <?php else: ?>
                                <span class="badge bg-success fs-6">Globale</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-16">
                    <div class="col-md-6">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Coopérative</span>
                            <span class="fw-medium"><?php echo e($facture->cooperative->nom); ?></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Statut</span>
                            <?php if($facture->statut === 'brouillon'): ?>
                                <span class="badge bg-warning">Brouillon</span>
                            <?php elseif($facture->statut === 'validee'): ?>
                                <span class="badge bg-info">Validée</span>
                            <?php elseif($facture->statut === 'payee'): ?>
                                <span class="badge bg-success">Payée</span>
                            <?php elseif($facture->statut === 'annulee'): ?>
                                <span class="badge bg-secondary">Annulée</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-16">
                    <div class="col-md-3">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Date d'émission</span>
                            <span class="fw-medium"><?php echo e($facture->date_emission->format('d/m/Y')); ?></span>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Date d'échéance</span>
                            <span class="fw-medium <?php echo e($facture->isEnRetard() ? 'text-danger' : ''); ?>">
                                <?php echo e($facture->date_echeance->format('d/m/Y')); ?>

                            </span>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Montant TTC</span>
                            <span class="fw-bold text-success text-lg"><?php echo e(number_format($facture->montant_ttc, 0)); ?> FCFA</span>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Montant payé</span>
                            <span class="fw-bold text-info text-lg"><?php echo e(number_format($facture->montant_paye, 0)); ?> FCFA</span>
                        </div>
                    </div>
                </div>
                
                <?php if($facture->montant_paye > 0): ?>
                <div class="row mt-16">
                    <div class="col-md-6">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Montant restant</span>
                            <span class="fw-bold text-warning text-lg"><?php echo e(number_format($facture->montant_restant, 0)); ?> FCFA</span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Date de paiement</span>
                            <span class="fw-medium"><?php echo e($facture->date_paiement ? $facture->date_paiement->format('d/m/Y') : '-'); ?></span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if($facture->conditions_paiement || $facture->notes): ?>
                <div class="row mt-16">
                    <?php if($facture->conditions_paiement): ?>
                    <div class="col-md-6">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Conditions de paiement</span>
                            <span class="fw-medium"><?php echo e($facture->conditions_paiement); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if($facture->notes): ?>
                    <div class="col-md-6">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Notes</span>
                            <span class="fw-medium"><?php echo e($facture->notes); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                
                <?php if($facture->valideePar): ?>
                <div class="row mt-16">
                    <div class="col-md-6">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Validée par</span>
                            <span class="fw-medium"><?php echo e($facture->valideePar->name); ?></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex flex-column">
                            <span class="text-sm text-muted mb-1">Date de validation</span>
                            <span class="fw-medium"><?php echo e($facture->date_validation->format('d/m/Y H:i')); ?></span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Détails des Tickets -->
        <div class="card h-100 p-0 radius-12">
            <div class="card-header border-bottom bg-base py-16 px-24">
                <h6 class="mb-0">Détails des Tickets Facturés</h6>
            </div>
            <div class="card-body p-24">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>N° Ticket</th>
                                <th>Date</th>
                                <th>Poids Net</th>
                                <th>Prix Final</th>
                                <th>Montant</th>
                                <th>Centre de Collecte</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $facture->factureTicketsPesee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factureTicket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $ticket = $factureTicket->ticketPesee;
                                ?>
                                <tr>
                                    <td>
                                        <span class="fw-medium"><?php echo e($ticket->numero_ticket); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-muted"><?php echo e($ticket->date_entree->format('d/m/Y')); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-success fw-bold"><?php echo e(number_format($ticket->poids_net, 2)); ?> kg</span>
                                    </td>
                                    <td>
                                        <span class="text-primary fw-bold"><?php echo e(number_format($factureTicket->montant_ticket / $ticket->poids_net, 2)); ?> FCFA/kg</span>
                                    </td>
                                    <td>
                                        <span class="text-success fw-bold"><?php echo e(number_format($factureTicket->montant_ticket, 0)); ?> FCFA</span>
                                    </td>
                                    <td>
                                        <span class="text-muted"><?php echo e($ticket->connaissement->centreCollecte->nom); ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="table-light">
                                <td colspan="4" class="text-end fw-bold">Total :</td>
                                <td class="fw-bold text-success"><?php echo e(number_format($facture->montant_ttc, 0)); ?> FCFA</td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('partials.wowdash-scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- Modal pour marquer comme payée -->
<div class="modal fade" id="markAsPaidModal" tabindex="-1" aria-labelledby="markAsPaidModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="markAsPaidModalLabel">Marquer comme payée</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="markAsPaidForm" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="montant_paye" class="form-label">Montant payé (FCFA)</label>
                        <input type="number" class="form-control" id="montant_paye" name="montant_paye" step="0.01" required>
                        <div class="form-text">Montant total de la facture : <span id="montantTotal"></span> FCFA</div>
                    </div>
                    <div class="mb-3">
                        <label for="date_paiement" class="form-label">Date de paiement</label>
                        <input type="date" class="form-control" id="date_paiement" name="date_paiement" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-success">Enregistrer le paiement</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function markAsPaid(factureId, montantTotal) {
    document.getElementById('montantTotal').textContent = montantTotal.toLocaleString();
    document.getElementById('montant_paye').value = montantTotal;
    document.getElementById('montant_paye').max = montantTotal;
    document.getElementById('markAsPaidForm').action = `/admin/factures/${factureId}/mark-as-paid`;
    document.getElementById('date_paiement').value = new Date().toISOString().split('T')[0];    
    new bootstrap.Modal(document.getElementById('markAsPaidModal')).show();
}
</script>

</body>
</html> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gr-hevea/resources/views/admin/factures/show.blade.php ENDPATH**/ ?>