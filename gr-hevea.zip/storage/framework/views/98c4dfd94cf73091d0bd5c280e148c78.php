<!DOCTYPE html>
<html lang="fr" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Administration'); ?></title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('wowdash/images/fph-ci.png')); ?>" sizes="16x16">
    
    <!-- WowDash CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/lib/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/lib/apexcharts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/lib/dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/style.css')); ?>">
    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
<?php echo $__env->make('partials.sidebar', ['navigation' => $navigation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="dashboard-main">
    <?php echo $__env->make('partials.navbar-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    
<!-- jQuery library js -->
<script src="<?php echo e(asset('wowdash/js/lib/jquery-3.7.1.min.js')); ?>"></script>
<!-- Bootstrap js -->
    <script src="<?php echo e(asset('wowdash/js/lib/bootstrap.bundle.min.js')); ?>"></script>
<!-- Iconify Font js -->
<script src="<?php echo e(asset('wowdash/js/lib/iconify-icon.min.js')); ?>"></script>
<!-- main js -->
    <script src="<?php echo e(asset('wowdash/js/app.js')); ?>"></script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gr-hevea/resources/views/layouts/app.blade.php ENDPATH**/ ?>