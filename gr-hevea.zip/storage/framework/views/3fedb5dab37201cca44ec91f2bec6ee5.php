<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Superadmin - Gestion des Utilisateurs</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome pour les icônes -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .status-badge {
            font-size: 0.8rem;
            padding: 0.25rem 0.5rem;
        }
        .action-buttons {
            white-space: nowrap;
        }
        .table-responsive {
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Header -->
        <div class="row bg-primary text-white p-3 mb-4">
            <div class="col">
                <h1><i class="fas fa-users-cog"></i> Dashboard Superadmin</h1>
                <p class="mb-0">Gestion des utilisateurs</p>
            </div>
            <div class="col-auto">
                <div class="d-flex align-items-center">
                    <span class="me-3">Connecté en tant que : <?php echo e(auth()->user()->full_name); ?></span>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-light btn-sm">
                            <i class="fas fa-sign-out-alt"></i> Déconnexion
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Messages de succès/erreur -->
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Bouton Ajouter Utilisateur -->
        <div class="row mb-4">
            <div class="col">
                <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-success">
                    <i class="fas fa-plus"></i> Ajouter un utilisateur
                </a>
            </div>
        </div>

        <!-- Tableau des utilisateurs -->
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-list"></i> Liste des utilisateurs</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Nom</th>
                                        <th>Email</th>
                                        <th>Rôle</th>
                                        <th>Secteur</th>
                                        <th>Fonction</th>
                                        <th>Siège</th>
                                        <th>Statut</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->full_name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo e($user->role === 'superadmin' ? 'dark' : ($user->role === 'admin' ? 'danger' : ($user->role === 'manager' ? 'warning' : 'info'))); ?>">
                                                <?php echo e($user->role === 'superadmin' ? 'Super Admin' : ucfirst($user->role)); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($user->secteur ?? 'Non défini'); ?></td>
                                        <td><?php echo e($user->fonction ? $user->fonction->nom : 'Non défini'); ?></td>
                                        <td>
                                            <?php if($user->siege): ?>
                                                <span class="badge bg-success">Oui</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Non</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($user->status === 'active'): ?>
                                                <span class="badge bg-success status-badge">Actif</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger status-badge">Inactif</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="action-buttons">
                                            <!-- Bouton Activer/Désactiver -->
                                            <form action="<?php echo e(route('admin.users.toggle-status', $user)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-sm <?php echo e($user->status === 'active' ? 'btn-warning' : 'btn-success'); ?>" 
                                                        title="<?php echo e($user->status === 'active' ? 'Désactiver' : 'Activer'); ?>">
                                                    <i class="fas <?php echo e($user->status === 'active' ? 'fa-ban' : 'fa-check'); ?>"></i>
                                                </button>
                                            </form>

                                            <!-- Bouton Éditer -->
                                            <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-sm btn-primary" title="Éditer">
                                                <i class="fas fa-edit"></i>
                                            </a>

                                            <!-- Bouton Supprimer -->
                                            <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST" class="d-inline" 
                                                  onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger" title="Supprimer">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gr-hevea/resources/views/admin/users/index.blade.php ENDPATH**/ ?>