<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="card-title mb-0">
                        <i class="fas fa-user me-2"></i>
                        Détails de l'utilisateur : <?php echo e($user->name); ?>

                    </h4>
                    <div>
                        <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-primary btn-sm me-2">
                            <i class="fas fa-edit me-1"></i>Modifier
                        </a>
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary btn-sm">
                            <i class="fas fa-arrow-left me-1"></i>Retour
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <!-- Informations de base -->
                        <div class="col-md-6">
                            <h5 class="text-primary mb-3">Informations de base</h5>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="fw-bold" style="width: 150px;">ID :</td>
                                    <td><?php echo e($user->id); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Nom d'utilisateur :</td>
                                    <td><?php echo e($user->username); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Prénom :</td>
                                    <td><?php echo e($user->name); ?></td>
                                </tr>

                                <tr>
                                    <td class="fw-bold">Email :</td>
                                    <td><?php echo e($user->email); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Rôle :</td>
                                    <td>
                                        <span class="badge bg-<?php echo e($user->role === 'superadmin' ? 'danger' : ($user->role === 'admin' ? 'warning' : ($user->role === 'manager' ? 'info' : 'secondary'))); ?>">
                                            <?php echo e(ucfirst($user->role)); ?>

                                        </span>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <!-- Informations professionnelles -->
                        <div class="col-md-6">
                            <h5 class="text-primary mb-3">Informations professionnelles</h5>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="fw-bold" style="width: 150px;">Fonction :</td>
                                    <td>
                                        <?php if($user->fonction): ?>
                                            <span class="badge bg-primary"><?php echo e($user->fonction->nom); ?></span>
                                            <br>
                                            <small class="text-muted"><?php echo e($user->fonction->description); ?></small>
                                        <?php else: ?>
                                            <span class="text-muted">Non définie</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Coopérative :</td>
                                    <td>
                                        <?php if($user->cooperative): ?>
                                            <span class="badge bg-success"><?php echo e($user->cooperative->nom); ?></span>
                                            <br>
                                            <small class="text-muted">Code: <?php echo e($user->cooperative->code); ?></small>
                                        <?php else: ?>
                                            <span class="text-muted">Non assignée</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Secteur :</td>
                                    <td>
                                        <?php if($user->secteurRelation): ?>
                                            <span class="badge bg-info"><?php echo e($user->secteurRelation->nom); ?></span>
                                            <br>
                                            <small class="text-muted">Code: <?php echo e($user->secteurRelation->code); ?></small>
                                        <?php elseif($user->secteur): ?>
                                            <span class="text-muted"><?php echo e($user->secteur); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">Non défini</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Centre de collecte :</td>
                                    <td>
                                        <?php if($user->centreCollecte): ?>
                                            <span class="badge bg-warning"><?php echo e($user->centreCollecte->nom); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">Non assigné</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <hr class="my-4">

                    <div class="row">
                        <!-- Statut et permissions -->
                        <div class="col-md-6">
                            <h5 class="text-primary mb-3">Statut et permissions</h5>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="fw-bold" style="width: 150px;">Statut :</td>
                                    <td>
                                        <span class="badge bg-<?php echo e($user->status === 'active' ? 'success' : 'danger'); ?>">
                                            <?php echo e($user->status === 'active' ? 'Actif' : 'Inactif'); ?>

                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Utilisateur du siège :</td>
                                    <td>
                                        <?php if($user->siege): ?>
                                            <span class="badge bg-success">Oui</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Non</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Peut gérer coopérative :</td>
                                    <td>
                                        <?php if($user->peutGererCooperative()): ?>
                                            <span class="badge bg-success">Oui</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Non</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Niveau d'accès :</td>
                                    <td>
                                        <?php if($user->fonction): ?>
                                            <span class="badge bg-info"><?php echo e(ucfirst($user->fonction->niveau_acces)); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">Non défini</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <!-- Informations système -->
                        <div class="col-md-6">
                            <h5 class="text-primary mb-3">Informations système</h5>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="fw-bold" style="width: 150px;">Créé le :</td>
                                    <td><?php echo e($user->created_at->format('d/m/Y à H:i')); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Dernière modification :</td>
                                    <td><?php echo e($user->updated_at->format('d/m/Y à H:i')); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold">Dernière connexion :</td>
                                    <td>
                                        <?php if($user->last_login_at): ?>
                                            <?php echo e(\Carbon\Carbon::parse($user->last_login_at)->format('d/m/Y à H:i')); ?>

                                        <?php else: ?>
                                            <span class="text-muted">Jamais connecté</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <?php if($user->fonction && $user->fonction->peut_gerer_cooperative && $user->cooperative): ?>
                    <hr class="my-4">
                    
                    <div class="row">
                        <div class="col-12">
                            <h5 class="text-primary mb-3">
                                <i class="fas fa-handshake me-2"></i>
                                Responsabilités de coopérative
                            </h5>
                            <div class="alert alert-info">
                                <strong><?php echo e($user->name); ?> <?php echo e($user->nom); ?></strong> est responsable de la coopérative 
                                <strong><?php echo e($user->cooperative->nom); ?></strong> (<?php echo e($user->cooperative->code); ?>).
                                <br>
                                <small class="text-muted">
                                    Cette fonction permet de gérer les producteurs, les tickets de pesée et les factures 
                                    de cette coopérative spécifique.
                                </small>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Actions -->
                    <div class="row mt-4">
                        <div class="col-12 text-center">
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-primary">
                                    <i class="fas fa-edit me-2"></i>Modifier l'utilisateur
                                </a>
                                <button type="button" class="btn btn-warning" onclick="resetPassword()">
                                    <i class="fas fa-key me-2"></i>Réinitialiser le mot de passe
                                </button>
                                <?php if($user->status === 'active'): ?>
                                    <button type="button" class="btn btn-danger" onclick="deactivateUser()">
                                        <i class="fas fa-user-slash me-2"></i>Désactiver
                                    </button>
                                <?php else: ?>
                                    <button type="button" class="btn btn-success" onclick="activateUser()">
                                        <i class="fas fa-user-check me-2"></i>Activer
                                    </button>
                                <?php endif; ?>
                                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left me-2"></i>Retour à la liste
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function resetPassword() {
    if (confirm('Êtes-vous sûr de vouloir réinitialiser le mot de passe de cet utilisateur ?')) {
        // Ici on pourrait faire une requête AJAX pour réinitialiser le mot de passe
        alert('Fonctionnalité de réinitialisation de mot de passe à implémenter');
    }
}

function deactivateUser() {
    if (confirm('Êtes-vous sûr de vouloir désactiver cet utilisateur ?')) {
        // Ici on pourrait faire une requête AJAX pour désactiver l'utilisateur
        alert('Fonctionnalité de désactivation à implémenter');
    }
}

function activateUser() {
    if (confirm('Êtes-vous sûr de vouloir activer cet utilisateur ?')) {
        // Ici on pourrait faire une requête AJAX pour activer l'utilisateur
        alert('Fonctionnalité d\'activation à implémenter');
    }
}
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gr-hevea/resources/views/admin/users/show.blade.php ENDPATH**/ ?>