<!DOCTYPE html>
<html lang="fr" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farmer Lists - Gestion des Livraisons - WowDash</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('wowdash/images/favicon.png')); ?>" sizes="16x16">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/lib/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/style.css')); ?>">
</head>
<body>
<?php echo $__env->make('partials.sidebar', ['navigation' => $navigation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<main class="dashboard-main">
    <?php echo $__env->make('partials.navbar-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="dashboard-main-body">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
            <h6 class="fw-semibold mb-0">Farmer Lists - Gestion des Livraisons</h6>
            <ul class="d-flex align-items-center gap-2">
                <li class="fw-medium">
                    <a href="<?php echo e(route('dashboard')); ?>" class="d-flex align-items-center gap-1 hover-text-primary">
                        <iconify-icon icon="solar:home-smile-angle-outline" class="icon text-lg"></iconify-icon>
                        Dashboard
                    </a>
                </li>
                <li>-</li>
                <li class="fw-medium">Farmer Lists</li>
            </ul>
        </div>

        <!-- Filtres -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form method="GET" action="<?php echo e(route('admin.farmer-lists.index')); ?>" class="row g-3">
                            <div class="col-md-3">
                                <label for="search" class="form-label">Rechercher</label>
                                <input type="text" class="form-control" id="search" name="search" 
                                       value="<?php echo e(request('search')); ?>" placeholder="Numéro de livraison...">
                            </div>
                            <div class="col-md-3">
                                <label for="cooperative_id" class="form-label">Coopérative</label>
                                <select class="form-select" id="cooperative_id" name="cooperative_id">
                                    <option value="">Toutes les coopératives</option>
                                    <?php $__currentLoopData = $cooperatives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cooperative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cooperative->id); ?>" 
                                                <?php echo e(request('cooperative_id') == $cooperative->id ? 'selected' : ''); ?>>
                                            <?php echo e($cooperative->nom); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="centre_collecte_id" class="form-label">Centre de Collecte</label>
                                <select class="form-select" id="centre_collecte_id" name="centre_collecte_id">
                                    <option value="">Tous les centres</option>
                                    <?php $__currentLoopData = $centresCollecte; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($centre->id); ?>" 
                                                <?php echo e(request('centre_collecte_id') == $centre->id ? 'selected' : ''); ?>>
                                            <?php echo e($centre->nom); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">&nbsp;</label>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">Filtrer</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tableau des livraisons -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Livraisons avec Farmer Lists</h5>
                    </div>
                    <div class="card-body">
                        <?php if($livraisons->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>N° Livraison</th>
                                            <th>Coopérative</th>
                                            <th>Centre de Collecte</th>
                                            <th>Poids Net (kg)</th>
                                            <th>Poids Farmer List (kg)</th>
                                            <th>État</th>
                                            <th>Date Livraison</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $livraisons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livraison): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <strong><?php echo e($livraison->numero_livraison); ?></strong>
                                                </td>
                                                <td><?php echo e($livraison->cooperative->nom); ?></td>
                                                <td><?php echo e($livraison->centreCollecte->nom); ?></td>
                                                <td><?php echo e(number_format($livraison->poids_net, 2)); ?></td>
                                                <td><?php echo e(number_format($livraison->poids_total_farmer_list, 2)); ?></td>
                                                <td>
                                                    <?php if($livraison->farmer_list_complete): ?>
                                                        <span class="badge bg-success">Complète</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-warning">Incomplète</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($livraison->created_at->format('d/m/Y')); ?></td>
                                                <td>
                                                    <div class="btn-group" role="group">
                                                        <a href="<?php echo e(route('admin.farmer-lists.show', $livraison)); ?>" 
                                                           class="btn btn-sm btn-outline-primary">
                                                            <iconify-icon icon="ri-eye-line"></iconify-icon> Voir
                                                        </a>
                                                        <?php if(!$livraison->farmer_list_complete): ?>
                                                            <a href="<?php echo e(route('admin.farmer-lists.create', $livraison)); ?>" 
                                                               class="btn btn-sm btn-outline-success">
                                                                <iconify-icon icon="ri-add-line"></iconify-icon> Ajouter
                                                            </a>
                                                        <?php endif; ?>
                                                        <a href="<?php echo e(route('admin.farmer-lists.pdf', $livraison)); ?>" 
                                                           class="btn btn-sm btn-outline-info" target="_blank">
                                                            <iconify-icon icon="ri-file-pdf-line"></iconify-icon> PDF
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Pagination -->
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div>
                                    Affichage de <?php echo e($livraisons->firstItem()); ?> à <?php echo e($livraisons->lastItem()); ?> 
                                    sur <?php echo e($livraisons->total()); ?> résultats
                                </div>
                                <div>
                                    <?php echo e($livraisons->links()); ?>

                                </div>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <iconify-icon icon="ri-inbox-line" class="display-1 text-muted"></iconify-icon>
                                <h5 class="mt-3">Aucune livraison trouvée</h5>
                                <p class="text-muted">Aucune livraison validée ne correspond à vos critères de recherche.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('partials.wowdash-scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gr-hevea/resources/views/admin/farmer-lists/index.blade.php ENDPATH**/ ?>