<!DOCTYPE html>
<html lang="fr" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier le Connaissement - WowDash</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('wowdash/images/favicon.png')); ?>" sizes="16x16">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/lib/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/lib/dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/style.css')); ?>">
</head>
<body>
<?php echo $__env->make('partials.sidebar', ['navigation' => $navigation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="dashboard-main">
    <?php echo $__env->make('partials.navbar-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <div class="dashboard-main-body">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
            <h6 class="fw-semibold mb-0">
                Modifier le Connaissement <?php echo e($connaissement->numero); ?>

            </h6>
            <ul class="d-flex align-items-center gap-2">
                <li class="fw-medium">
                    <a href="<?php echo e(route('dashboard')); ?>" class="d-flex align-items-center gap-1 hover-text-primary">
                        <iconify-icon icon="solar:home-smile-angle-outline" class="icon text-lg"></iconify-icon>
                        Dashboard
                    </a>
                </li>
                <li>-</li>
                <li class="fw-medium">
                    <a href="<?php echo e(route('admin.connaissements.index')); ?>" class="hover-text-primary">Connaissements</a>
                </li>
                <li>-</li>
                <li class="fw-medium">Modifier <?php echo e($connaissement->numero); ?></li>
            </ul>
        </div>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="ri-error-warning-line me-2"></i><?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="ri-check-line me-2"></i><?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.connaissements.update', $connaissement)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <div class="row">
                <!-- Informations de Base -->
                <div class="col-lg-6">
                    <div class="card h-100 p-0 radius-12">
                        <div class="card-header border-bottom bg-base py-16 px-24">
                            <h6 class="mb-0">Informations de Base</h6>
                        </div>
                        <div class="card-body p-24">
                            <div class="mb-3">
                                <label for="numero" class="form-label">Numéro de Connaissement</label>
                                <input type="text" class="form-control" value="<?php echo e($connaissement->numero); ?>" readonly>
                                <small class="text-muted">Numéro généré automatiquement</small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="cooperative_id" class="form-label">Coopérative *</label>
                                <select name="cooperative_id" id="cooperative_id" class="form-select <?php $__errorArgs = ['cooperative_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="">Sélectionner une coopérative</option>
                                    <?php $__currentLoopData = $cooperatives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cooperative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cooperative->id); ?>" <?php echo e($connaissement->cooperative_id == $cooperative->id ? 'selected' : ''); ?>>
                                            <?php echo e($cooperative->nom); ?> (<?php echo e($cooperative->sigle); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['cooperative_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="centre_collecte_id" class="form-label">Centre de Collecte *</label>
                                <select name="centre_collecte_id" id="centre_collecte_id" class="form-select <?php $__errorArgs = ['centre_collecte_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="">Sélectionner un centre de collecte</option>
                                    <?php $__currentLoopData = $centresCollecte; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($centre->id); ?>" <?php echo e($connaissement->centre_collecte_id == $centre->id ? 'selected' : ''); ?>>
                                            <?php echo e($centre->code); ?> - <?php echo e($centre->nom); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['centre_collecte_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="statut" class="form-label">Statut</label>
                                <select name="statut" id="statut" class="form-select <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="programme" <?php echo e($connaissement->statut == 'programme' ? 'selected' : ''); ?>>Programmé</option>
                                    <option value="valide" <?php echo e($connaissement->statut == 'valide' ? 'selected' : ''); ?>>Validé pour ticket de pesée</option>
                                </select>
                                <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Informations de Transport -->
                <div class="col-lg-6">
                    <div class="card h-100 p-0 radius-12">
                        <div class="card-header border-bottom bg-base py-16 px-24">
                            <h6 class="mb-0">Informations de Transport</h6>
                        </div>
                        <div class="card-body p-24">
                            <div class="mb-3">
                                <label for="lieu_depart" class="form-label">Lieu de Départ *</label>
                                <input type="text" name="lieu_depart" id="lieu_depart" class="form-control <?php $__errorArgs = ['lieu_depart'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       value="<?php echo e(old('lieu_depart', $connaissement->lieu_depart)); ?>" required>
                                <?php $__errorArgs = ['lieu_depart'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="sous_prefecture" class="form-label">Sous-Préfecture *</label>
                                <input type="text" name="sous_prefecture" id="sous_prefecture" class="form-control <?php $__errorArgs = ['sous_prefecture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       value="<?php echo e(old('sous_prefecture', $connaissement->sous_prefecture)); ?>" required>
                                <?php $__errorArgs = ['sous_prefecture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="transporteur_nom" class="form-label">Nom du Transporteur *</label>
                                <input type="text" name="transporteur_nom" id="transporteur_nom" class="form-control <?php $__errorArgs = ['transporteur_nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       value="<?php echo e(old('transporteur_nom', $connaissement->transporteur_nom)); ?>" required>
                                <?php $__errorArgs = ['transporteur_nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="transporteur_immatriculation" class="form-label">Immatriculation du Camion *</label>
                                <input type="text" name="transporteur_immatriculation" id="transporteur_immatriculation" class="form-control <?php $__errorArgs = ['transporteur_immatriculation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       value="<?php echo e(old('transporteur_immatriculation', $connaissement->transporteur_immatriculation)); ?>" required>
                                <?php $__errorArgs = ['transporteur_immatriculation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="chauffeur_nom" class="form-label">Nom du Chauffeur *</label>
                                <input type="text" name="chauffeur_nom" id="chauffeur_nom" class="form-control <?php $__errorArgs = ['chauffeur_nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       value="<?php echo e(old('chauffeur_nom', $connaissement->chauffeur_nom)); ?>" required>
                                <?php $__errorArgs = ['chauffeur_nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row mt-24">
                <!-- Informations de Marchandise -->
                <div class="col-lg-6">
                    <div class="card h-100 p-0 radius-12">
                        <div class="card-header border-bottom bg-base py-16 px-24">
                            <h6 class="mb-0">Informations de Marchandise</h6>
                        </div>
                        <div class="card-body p-24">
                            <div class="mb-3">
                                <label for="destinataire_type" class="form-label">Type de Destinataire *</label>
                                <select name="destinataire_type" id="destinataire_type" class="form-select <?php $__errorArgs = ['destinataire_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="entrepot" <?php echo e($connaissement->destinataire_type == 'entrepot' ? 'selected' : ''); ?>>Entrepôt</option>
                                    <option value="cooperative" <?php echo e($connaissement->destinataire_type == 'cooperative' ? 'selected' : ''); ?>>Coopérative</option>
                                    <option value="acheteur" <?php echo e($connaissement->destinataire_type == 'acheteur' ? 'selected' : ''); ?>>Acheteur</option>
                                </select>
                                <?php $__errorArgs = ['destinataire_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="destinataire_id" class="form-label">ID du Destinataire</label>
                                <input type="number" name="destinataire_id" id="destinataire_id" class="form-control <?php $__errorArgs = ['destinataire_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       value="<?php echo e(old('destinataire_id', $connaissement->destinataire_id)); ?>">
                                <?php $__errorArgs = ['destinataire_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="nombre_sacs" class="form-label">Nombre de Sacs *</label>
                                <input type="number" name="nombre_sacs" id="nombre_sacs" class="form-control <?php $__errorArgs = ['nombre_sacs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       value="<?php echo e(old('nombre_sacs', $connaissement->nombre_sacs)); ?>" min="1" required>
                                <?php $__errorArgs = ['nombre_sacs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="poids_brut_estime" class="form-label">Poids Brut Estimé (kg) *</label>
                                <input type="number" name="poids_brut_estime" id="poids_brut_estime" class="form-control <?php $__errorArgs = ['poids_brut_estime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       value="<?php echo e(old('poids_brut_estime', $connaissement->poids_brut_estime)); ?>" step="0.01" min="0.01" required>
                                <?php $__errorArgs = ['poids_brut_estime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Informations de Validation -->
                <div class="col-lg-6">
                    <div class="card h-100 p-0 radius-12">
                        <div class="card-header border-bottom bg-base py-16 px-24">
                            <h6 class="mb-0">Informations de Validation</h6>
                        </div>
                        <div class="card-body p-24">
                            <div class="mb-3">
                                <label for="signature_cooperative" class="form-label">Signature de la Coopérative</label>
                                <input type="text" name="signature_cooperative" id="signature_cooperative" class="form-control <?php $__errorArgs = ['signature_cooperative'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       value="<?php echo e(old('signature_cooperative', $connaissement->signature_cooperative)); ?>">
                                <?php $__errorArgs = ['signature_cooperative'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Créé par</label>
                                <input type="text" class="form-control" value="<?php echo e($connaissement->createdBy->name ?? 'N/A'); ?>" readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Date de création</label>
                                <input type="text" class="form-control" value="<?php echo e($connaissement->created_at->format('d/m/Y H:i')); ?>" readonly>
                            </div>
                            
                            <?php if($connaissement->validatedBy): ?>
                                <div class="mb-3">
                                    <label class="form-label">Validé par</label>
                                    <input type="text" class="form-control" value="<?php echo e($connaissement->validatedBy->name); ?>" readonly>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Date de validation</label>
                                    <input type="text" class="form-control" value="<?php echo e($connaissement->date_validation ? $connaissement->date_validation->format('d/m/Y H:i') : 'N/A'); ?>" readonly>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Boutons d'Action -->
            <div class="row mt-24">
                <div class="col-12">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('admin.connaissements.index')); ?>" class="btn btn-outline-secondary">
                            <iconify-icon icon="lucide:x" class="icon me-1"></iconify-icon>
                            Annuler
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <iconify-icon icon="lucide:save" class="icon me-1"></iconify-icon>
                            Mettre à Jour
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</main>

<?php echo $__env->make('partials.wowdash-scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script>
// Validation côté client
document.querySelector('form').addEventListener('submit', function(e) {
    const requiredFields = document.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            isValid = false;
        } else {
            field.classList.remove('is-invalid');
        }
    });
    
    if (!isValid) {
        e.preventDefault();
        alert('Veuillez remplir tous les champs obligatoires.');
    }
});
</script>
</body>
</html> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gr-hevea/resources/views/admin/connaissements/edit.blade.php ENDPATH**/ ?>