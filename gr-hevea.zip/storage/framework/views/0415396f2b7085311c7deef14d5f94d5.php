<!DOCTYPE html>
<html lang="fr" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Coopérative - WowDash</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('wowdash/images/favicon.png')); ?>" sizes="16x16">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/lib/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/style.css')); ?>">
</head>
<body>
<?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<main class="dashboard-main">
    <?php echo $__env->make('partials.navbar-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="dashboard-main-body">
        <form action="<?php echo e(route('admin.cooperatives.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
                <h6 class="fw-semibold mb-0">Ajouter une Coopérative</h6>
                <ul class="d-flex align-items-center gap-2">
                    <li class="fw-medium">
                        <a href="<?php echo e(route('admin.cooperatives.index')); ?>" class="d-flex align-items-center gap-1 hover-text-primary">
                            <iconify-icon icon="solar:home-smile-angle-outline" class="icon text-lg"></iconify-icon>
                            Liste des Coopératives
                        </a>
                    </li>
                    <li>-</li>
                    <li class="fw-medium">Ajouter</li>
                </ul>
            </div>
            <div class="card p-24 radius-12 mb-24">
                <h5 class="card-title mb-4"><iconify-icon icon="solar:info-square-outline" class="me-2 text-primary"></iconify-icon> Informations générales</h5>
                <div class="row gy-3">
                    <div class="col-md-6">
                        <label for="code" class="form-label">Code de la coopérative *</label>
                        <input type="text" class="form-control" id="code" name="code" value="<?php echo e(old('code')); ?>" required>
                        <div class="form-text">Exemple: AB01-COOP1, COT1-COOP1, etc.</div>
                    </div>
                    <div class="col-md-6">
                        <label for="nom" class="form-label">Nom de la coopérative *</label>
                        <input type="text" class="form-control" id="nom" name="nom" value="<?php echo e(old('nom')); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="secteur_id" class="form-label">Secteur *</label>
                        <select class="form-select" id="secteur_id" name="secteur_id" required>
                            <option value="">Sélectionner un secteur</option>
                            <?php $__currentLoopData = $secteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secteur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($secteur->id); ?>" <?php echo e(old('secteur_id') == $secteur->id ? 'selected' : ''); ?>><?php echo e($secteur->code); ?> - <?php echo e($secteur->nom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="president" class="form-label">Nom du président *</label>
                        <input type="text" class="form-control" id="president" name="president" value="<?php echo e(old('president')); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="contact" class="form-label">Contact (10 chiffres) *</label>
                        <input type="text" class="form-control" id="contact" name="contact" value="<?php echo e(old('contact')); ?>" required maxlength="10">
                    </div>
                    <div class="col-md-4">
                        <label for="sigle" class="form-label">Sigle</label>
                        <input type="text" class="form-control" id="sigle" name="sigle" value="<?php echo e(old('sigle')); ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="latitude" class="form-label">Latitude</label>
                        <input type="text" class="form-control" id="latitude" name="latitude" value="<?php echo e(old('latitude')); ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="longitude" class="form-label">Longitude</label>
                        <input type="text" class="form-control" id="longitude" name="longitude" value="<?php echo e(old('longitude')); ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="a_sechoir" class="form-label">Séchoir</label>
                        <select class="form-select" id="a_sechoir" name="a_sechoir">
                            <option value="0" <?php echo e(old('a_sechoir') == '0' ? 'selected' : ''); ?>>Non</option>
                            <option value="1" <?php echo e(old('a_sechoir') == '1' ? 'selected' : ''); ?>>Oui</option>
                        </select>
                        <div class="form-text">La coopérative dispose-t-elle d'un séchoir ?</div>
                    </div>
                </div>
            </div>
            
            <!-- Nouvelle section pour les distances -->
            <div class="card p-24 radius-12 mb-24">
                <h5 class="card-title mb-4">
                    <iconify-icon icon="solar:route-outline" class="me-2 text-info"></iconify-icon> 
                    Distances vers les centres de collecte (en km)
                </h5>
                <div class="row gy-3">
                    <div class="col-md-4">
                        <label for="distance_cotraf" class="form-label">Usine COTRAF *</label>
                        <input type="number" step="0.1" min="0" class="form-control" id="distance_cotraf" name="distances[cotraf]" value="<?php echo e(old('distances.cotraf')); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label for="distance_duekoue" class="form-label">Duekoué *</label>
                        <input type="number" step="0.1" min="0" class="form-control" id="distance_duekoue" name="distances[duekoue]" value="<?php echo e(old('distances.duekoue')); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label for="distance_guiglo" class="form-label">Guiglo *</label>
                        <input type="number" step="0.1" min="0" class="form-control" id="distance_guiglo" name="distances[guiglo]" value="<?php echo e(old('distances.guiglo')); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label for="distance_divo" class="form-label">Divo *</label>
                        <input type="number" step="0.1" min="0" class="form-control" id="distance_divo" name="distances[divo]" value="<?php echo e(old('distances.divo')); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label for="distance_abengourou" class="form-label">Abengourou *</label>
                        <input type="number" step="0.1" min="0" class="form-control" id="distance_abengourou" name="distances[abengourou]" value="<?php echo e(old('distances.abengourou')); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label for="distance_meagui" class="form-label">Méagui *</label>
                        <input type="number" step="0.1" min="0" class="form-control" id="distance_meagui" name="distances[meagui]" value="<?php echo e(old('distances.meagui')); ?>" required>
                    </div>
                </div>
                <div class="alert alert-info mt-3">
                    <i class="ri-information-line me-2"></i>
                    <strong>Information :</strong> Ces distances seront utilisées pour calculer le coût de transport lors de la facturation.
                </div>
            </div>
            
            <div class="card p-24 radius-12 mb-24">
                <h5 class="card-title mb-4"><iconify-icon icon="solar:bank-outline" class="me-2 text-success"></iconify-icon> Données bancaires</h5>
                <div class="row gy-3">
                    <div class="col-md-3">
                        <label for="compte_bancaire" class="form-label">Compte (12 chiffres) *</label>
                        <input type="text" class="form-control" id="compte_bancaire" name="compte_bancaire" value="<?php echo e(old('compte_bancaire')); ?>" required maxlength="12">
                    </div>
                    <div class="col-md-2">
                        <label for="code_banque" class="form-label">Code banque (5 chiffres) *</label>
                        <input type="text" class="form-control" id="code_banque" name="code_banque" value="<?php echo e(old('code_banque')); ?>" required maxlength="5">
                    </div>
                    <div class="col-md-2">
                        <label for="code_guichet" class="form-label">Code guichet (5 chiffres) *</label>
                        <input type="text" class="form-control" id="code_guichet" name="code_guichet" value="<?php echo e(old('code_guichet')); ?>" required maxlength="5">
                    </div>
                    <div class="col-md-5">
                        <label for="nom_cooperative_banque" class="form-label">Nom de la coopérative à la banque *</label>
                        <input type="text" class="form-control" id="nom_cooperative_banque" name="nom_cooperative_banque" value="<?php echo e(old('nom_cooperative_banque')); ?>" required>
                    </div>
                </div>
            </div>
            <div class="card p-24 radius-12 mb-24">
                <h5 class="card-title mb-4"><iconify-icon icon="solar:document-text-outline" class="me-2 text-warning"></iconify-icon> Documents de traçabilité</h5>
                <div class="row gy-3">
                    <?php $__currentLoopData = $documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <label for="<?php echo e($key); ?>" class="form-label"><?php echo e($label); ?></label>
                        <input type="file" class="form-control" id="<?php echo e($key); ?>" name="<?php echo e($key); ?>" accept=".pdf,image/*">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="d-flex gap-3">
                <button type="submit" class="btn btn-success px-4">Créer la coopérative</button>
                <a href="<?php echo e(route('admin.cooperatives.index')); ?>" class="btn btn-secondary px-4">Annuler</a>
            </div>
        </form>
    </div>
</main>
<?php echo $__env->make('partials.wowdash-scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gr-hevea/resources/views/admin/cooperatives/create.blade.php ENDPATH**/ ?>