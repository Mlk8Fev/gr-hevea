<?php $__env->startSection('title', 'Statistiques Avancées'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-body">
    <!-- Breadcrumb -->
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
        <h6 class="fw-semibold mb-0">Statistiques Avancées</h6>
        <ul class="d-flex align-items-center gap-2">
            <li class="fw-medium">
                <a href="<?php echo e(route('dashboard')); ?>" class="d-flex align-items-center gap-1 hover-text-primary">
                    <iconify-icon icon="solar:home-smile-angle-outline" class="icon text-lg"></iconify-icon>
                    Dashboard
                </a>
            </li>
            <li>-</li>
            <li class="fw-medium">
                <a href="<?php echo e(route('admin.statistiques.index')); ?>" class="hover-text-primary">
                    Statistiques
                </a>
            </li>
            <li>-</li>
            <li class="fw-medium">Avancées</li>
        </ul>
    </div>

            <!-- Filtres et Navigation -->
    <!-- Filtres et Navigation Moderne WowDash -->
    <div class="card radius-8 border-0 mb-32">
        <div class="card-body p-24">
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-20">
                <div>
                    <h6 class="fw-bold text-lg mb-0">Analyse Détaillée</h6>
                    <span class="text-sm fw-medium text-secondary-light">Filtrez et explorez vos données en profondeur</span>
                </div>
                <a href="<?php echo e(route('admin.statistiques.index')); ?>" class="text-primary-600 hover-text-primary d-flex align-items-center gap-1">
                    <iconify-icon icon="solar:alt-arrow-left-linear" class="icon"></iconify-icon>
                    Retour aux Statistiques Basiques
                </a>
            </div>
            
            <form method="GET" action="<?php echo e(route('admin.statistiques.avancees')); ?>" class="row gy-3">
                <div class="col-xxl-3 col-md-6">
                    <label for="date_debut" class="form-label fw-semibold text-primary-light text-sm mb-8">Date de Début</label>
                    <input type="date" class="form-control radius-8 h-48-px" id="date_debut" name="date_debut" 
                           value="<?php echo e($dateDebut->format('Y-m-d')); ?>">
                </div>
                <div class="col-xxl-3 col-md-6">
                    <label for="date_fin" class="form-label fw-semibold text-primary-light text-sm mb-8">Date de Fin</label>
                    <input type="date" class="form-control radius-8 h-48-px" id="date_fin" name="date_fin" 
                           value="<?php echo e($dateFin->format('Y-m-d')); ?>">
                </div>
                <div class="col-xxl-4 col-md-8">
                    <label for="type" class="form-label fw-semibold text-primary-light text-sm mb-8">Type de Statistiques</label>
                    <select class="form-select radius-8 h-48-px" id="type" name="type">
                        <option value="generales" <?php echo e($type == 'generales' ? 'selected' : ''); ?>>📊 Générales</option>
                        <option value="cooperatives" <?php echo e($type == 'cooperatives' ? 'selected' : ''); ?>>🤝 Coopératives</option>
                        <option value="logistiques" <?php echo e($type == 'logistiques' ? 'selected' : ''); ?>>🚚 Logistiques</option>
                        <option value="financieres" <?php echo e($type == 'financieres' ? 'selected' : ''); ?>>💰 Financières</option>
                        <option value="qualite" <?php echo e($type == 'qualite' ? 'selected' : ''); ?>>⭐ Qualité</option>
                    </select>
                </div>
                <div class="col-xxl-2 col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary h-48-px px-24 w-100 radius-8 d-flex align-items-center justify-content-center gap-2">
                        <iconify-icon icon="hugeicons:analytics-02" class="icon"></iconify-icon>
                        Analyser
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Navigation par Catégories -->
    <div class="d-flex flex-wrap align-items-center justify-content-center gap-1 mb-32">
        <ul class="nav bordered-tab nav-pills mb-0" id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link d-flex align-items-center <?php echo e($type == 'generales' ? 'active' : ''); ?>" 
                   href="<?php echo e(route('admin.statistiques.avancees', ['type' => 'generales', 'date_debut' => $dateDebut->format('Y-m-d'), 'date_fin' => $dateFin->format('Y-m-d')])); ?>">
                    <iconify-icon icon="solar:chart-outline" class="me-6"></iconify-icon>
                    Générales
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link d-flex align-items-center <?php echo e($type == 'cooperatives' ? 'active' : ''); ?>" 
                   href="<?php echo e(route('admin.statistiques.avancees', ['type' => 'cooperatives', 'date_debut' => $dateDebut->format('Y-m-d'), 'date_fin' => $dateFin->format('Y-m-d')])); ?>">
                    <iconify-icon icon="solar:users-group-rounded-outline" class="me-6"></iconify-icon>
                    Coopératives
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link d-flex align-items-center <?php echo e($type == 'logistiques' ? 'active' : ''); ?>" 
                   href="<?php echo e(route('admin.statistiques.avancees', ['type' => 'logistiques', 'date_debut' => $dateDebut->format('Y-m-d'), 'date_fin' => $dateFin->format('Y-m-d')])); ?>">
                    <iconify-icon icon="solar:delivery-outline" class="me-6"></iconify-icon>
                    Logistiques
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link d-flex align-items-center <?php echo e($type == 'financieres' ? 'active' : ''); ?>" 
                   href="<?php echo e(route('admin.statistiques.avancees', ['type' => 'financieres', 'date_debut' => $dateDebut->format('Y-m-d'), 'date_fin' => $dateFin->format('Y-m-d')])); ?>">
                    <iconify-icon icon="solar:wallet-money-outline" class="me-6"></iconify-icon>
                    Financières
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link d-flex align-items-center <?php echo e($type == 'qualite' ? 'active' : ''); ?>" 
                   href="<?php echo e(route('admin.statistiques.avancees', ['type' => 'qualite', 'date_debut' => $dateDebut->format('Y-m-d'), 'date_fin' => $dateFin->format('Y-m-d')])); ?>">
                    <iconify-icon icon="solar:star-outline" class="me-6"></iconify-icon>
                    Qualité
                </a>
            </li>
        </ul>
    </div>

            <!-- Contenu Dynamique selon le Type -->
            <?php if($type == 'generales'): ?>
                <?php echo $__env->make('admin.statistiques.partials.generales', ['stats' => $stats], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php elseif($type == 'cooperatives'): ?>
                <?php echo $__env->make('admin.statistiques.partials.cooperatives', ['stats' => $stats], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php elseif($type == 'logistiques'): ?>
                <?php echo $__env->make('admin.statistiques.partials.logistiques', ['stats' => $stats], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php elseif($type == 'financieres'): ?>
                <?php echo $__env->make('admin.statistiques.partials.financieres', ['stats' => $stats], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php elseif($type == 'qualite'): ?>
                <?php echo $__env->make('admin.statistiques.partials.qualite', ['stats' => $stats], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Apex Chart js -->
<script src="<?php echo e(asset('wowdash/js/lib/apexcharts.min.js')); ?>"></script>
<script>
// Configuration WowDash pour les statistiques avancées
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Initialisation des statistiques avancées WowDash');
    
    // Données pour les graphiques
    const statsData = <?php echo json_encode($stats ?? [], 15, 512) ?>;
    const statsType = '<?php echo e($type); ?>';
    
    console.log('Type de statistiques:', statsType);
    console.log('Données:', statsData);

// Fonctions spécifiques aux statistiques avancées
function initGeneralCharts() {
    // Graphiques pour les statistiques générales
    const evolutionData = <?php echo json_encode($stats['evolution_mensuelle'] ?? [], 15, 512) ?>;
    
    if (document.getElementById('generalEvolutionChart')) {
        const ctx = document.getElementById('generalEvolutionChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: evolutionData.map(item => {
                    const [year, month] = item.mois.split('-');
                    const monthNames = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 
                                      'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];
                    return monthNames[parseInt(month) - 1] + ' ' + year;
                }),
                datasets: [{
                    label: 'Production (Kg)',
                    data: evolutionData.map(item => item.total),
                    borderColor: '#20c997',
                    backgroundColor: 'rgba(32, 201, 151, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return new Intl.NumberFormat('fr-FR').format(value) + ' Kg';
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Production: ' + new Intl.NumberFormat('fr-FR').format(context.parsed.y) + ' Kg';
                            }
                        }
                    }
                }
            }
        });
    }
}

function initCooperativesCharts() {
    // Graphiques pour les coopératives (déjà défini dans le partial)
    console.log('📊 Graphiques coopératives initialisés via partial');
}

function initLogisticsCharts() {
    // Graphiques pour la logistique (déjà défini dans le partial)
    console.log('🚚 Graphiques logistiques initialisés via partial');
}

function initFinancialCharts() {
    // Graphiques financiers (déjà défini dans le partial)
    console.log('💰 Graphiques financiers initialisés via partial');
}

function initQualityCharts() {
    // Graphiques de qualité (déjà défini dans le partial)
    console.log('⭐ Graphiques qualité initialisés via partial');
}

// Fonctions de tri pour les tableaux
function sortTable(criteria) {
    console.log('🔄 Tri du tableau par:', criteria);
    
    // Mise à jour de l'apparence des boutons
    document.querySelectorAll('.btn-group .btn').forEach(btn => {
        btn.classList.remove('active');
    });
    if (event && event.target) {
        event.target.closest('.btn').classList.add('active');
    }
}

function sortQualityTable(criteria) {
    console.log('🔄 Tri du tableau qualité par:', criteria);
    
    // Mise à jour de l'apparence des boutons
    document.querySelectorAll('.btn-group .btn').forEach(btn => {
        btn.classList.remove('active');
    });
    if (event && event.target) {
        event.target.closest('.btn').classList.add('active');
    }
}

// Exposer les fonctions globalement pour les vues partielles
window.sortTable = sortTable;
window.sortQualityTable = sortQualityTable;
window.initGeneralCharts = initGeneralCharts;
window.initCooperativesCharts = initCooperativesCharts;
window.initLogisticsCharts = initLogisticsCharts;
window.initFinancialCharts = initFinancialCharts;
window.initQualityCharts = initQualityCharts;

// Exposer les fonctions d'export
window.setQuickPeriod = function(period) {
    if (window.statistiques && window.statistiques.setQuickPeriod) {
        window.statistiques.setQuickPeriod(period);
    }
};

window.exportToExcel = function(button) {
    if (window.statistiques && window.statistiques.exportToExcel) {
        window.statistiques.exportToExcel(button);
    }
};

window.exportToPDF = function(button) {
    if (window.statistiques && window.statistiques.exportToPDF) {
        window.statistiques.exportToPDF(button);
    }
};

window.printChart = function(button) {
    if (window.statistiques && window.statistiques.printChart) {
        window.statistiques.printChart(button);
    }
};
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.nav-pills .nav-link {
    border-radius: 0.5rem;
    margin: 0 2px;
    transition: all 0.2s ease-in-out;
}

.nav-pills .nav-link:hover {
    background-color: rgba(13, 110, 253, 0.1);
    color: #0d6efd;
}

.nav-pills .nav-link.active {
    background-color: #0d6efd;
    color: white;
}

.card {
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    border: 1px solid rgba(0, 0, 0, 0.125);
}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gr-hevea/resources/views/admin/statistiques/avancees.blade.php ENDPATH**/ ?>