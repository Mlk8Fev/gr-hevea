<!DOCTYPE html>
<html lang="fr" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Valider le Connaissement - WowDash</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('wowdash/images/favicon.png')); ?>" sizes="16x16">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/lib/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('wowdash/css/style.css')); ?>">
</head>
<body>
<?php echo $__env->make('partials.sidebar', ['navigation' => $navigation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<main class="dashboard-main">
    <?php echo $__env->make('partials.navbar-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="dashboard-main-body">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
            <h6 class="fw-semibold mb-0">Valider le Connaissement</h6>
            <ul class="d-flex align-items-center gap-2">
                <li class="fw-medium">
                    <a href="<?php echo e(route('dashboard')); ?>" class="d-flex align-items-center gap-1 hover-text-primary">
                        <iconify-icon icon="solar:home-smile-angle-outline" class="icon text-lg"></iconify-icon>
                        Dashboard
                    </a>
                </li>
                <li>-</li>
                <li class="fw-medium">
                    <a href="<?php echo e(route('admin.connaissements.index')); ?>" class="d-flex align-items-center gap-1 hover-text-primary">
                        Connaissements
                    </a>
                </li>
                <li>-</li>
                <li class="fw-medium">Valider <?php echo e($connaissement->numero); ?></li>
            </ul>
        </div>
        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="ri-error-warning-line me-2"></i>
                <strong>Erreurs :</strong>
                <ul class="mb-0 mt-1">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card h-100 p-0 radius-12">
            <div class="card-header border-bottom bg-base py-16 px-24">
                <h6 class="mb-0">Validation du Connaissement</h6>
            </div>
            <div class="card-body p-24">
                <!-- Informations du connaissement -->
                <div class="row mb-4">
                    <div class="col-12">
                        <h6 class="fw-semibold mb-3 text-primary">
                            <iconify-icon icon="majesticons:file-list-line" class="icon me-2"></iconify-icon>
                            Détails du Connaissement
                        </h6>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Numéro :</label>
                            <p class="form-control-plaintext"><?php echo e($connaissement->numero); ?></p>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Coopérative :</label>
                            <p class="form-control-plaintext"><?php echo e($connaissement->cooperative->nom); ?></p>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Centre de Collecte :</label>
                            <p class="form-control-plaintext"><?php echo e($connaissement->centreCollecte->nom); ?></p>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Transporteur :</label>
                            <p class="form-control-plaintext"><?php echo e($connaissement->transporteur_nom); ?></p>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Poids Brut Estimé :</label>
                            <p class="form-control-plaintext"><?php echo e(number_format($connaissement->poids_brut_estime, 2)); ?> kg</p>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Nombre de Sacs :</label>
                            <p class="form-control-plaintext"><?php echo e($connaissement->nombre_sacs); ?></p>
                        </div>
                    </div>
                    
                    <?php if($connaissement->date_reception): ?>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Date de Réception Programmée :</label>
                            <p class="form-control-plaintext"><?php echo e($connaissement->date_reception->format('d/m/Y')); ?></p>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Heure d'Arrivée Programmée :</label>
                            <p class="form-control-plaintext"><?php echo e($connaissement->heure_arrivee); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Formulaire de validation -->
                <form action="<?php echo e(route('admin.connaissements.store-validation', $connaissement)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="fw-semibold mb-3 text-primary">
                                <iconify-icon icon="lucide:check" class="icon me-2"></iconify-icon>
                                Validation de la Livraison
                            </h6>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="poids_net_reel" class="form-label">Poids Net Réel (kg) *</label>
                                <input type="number" step="0.01" class="form-control <?php $__errorArgs = ['poids_net_reel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="poids_net_reel" name="poids_net_reel" 
                                       value="<?php echo e(old('poids_net_reel')); ?>" 
                                       placeholder="Poids réel mesuré" min="0.01" required>
                                <?php $__errorArgs = ['poids_net_reel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <small class="form-text text-muted">
                                    Poids réel mesuré à l'arrivée du camion
                                </small>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="signature_fphci" class="form-label">Signature FPH-CI</label>
                                <textarea class="form-control <?php $__errorArgs = ['signature_fphci'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                          id="signature_fphci" name="signature_fphci" rows="3" 
                                          placeholder="Signature du contrôleur usine"><?php echo e(old('signature_fphci')); ?></textarea>
                                <?php $__errorArgs = ['signature_fphci'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="alert alert-warning">
                        <i class="ri-error-warning-line me-2"></i>
                        <strong>Attention :</strong> Une fois validé pour ticket de pesée, le connaissement ne pourra plus être modifié.
                    </div>
                    
                    <div class="d-flex justify-content-between">
                        <a href="<?php echo e(route('admin.connaissements.index')); ?>" class="btn btn-secondary">
                            <i class="ri-arrow-left-line me-1"></i> Retour
                        </a>
                        <button type="submit" class="btn btn-success">
                            <i class="ri-check-line me-1"></i> Valider le Connaissement
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('partials.wowdash-scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gr-hevea/resources/views/admin/connaissements/validate.blade.php ENDPATH**/ ?>